# Changelog

All notable changes to this project will be documented in this file.

## [0.2.0] - 2025-03-14

### Added